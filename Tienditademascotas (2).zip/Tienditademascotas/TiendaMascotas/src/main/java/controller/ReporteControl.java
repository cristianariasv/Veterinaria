/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import DAOImplement.MascotaDAOImp;
import DAOImplement.ClienteDAOImp;
import DAOImplement.ConsultaDAOImp;
import modelo.Cliente;
import modelo.Mascota;
import modelo.Consulta;
import java.util.List;

public class ReporteControl {

    private final MascotaDAOImp mascotaDAO = new MascotaDAOImp();
    private final ClienteDAOImp clienteDAO = new ClienteDAOImp();
    private final ConsultaDAOImp consultaDAO = new ConsultaDAOImp();

    public String obtenerMascotasPorCliente(int clienteId) {
        StringBuilder sb = new StringBuilder();
        try {
            Cliente cliente = clienteDAO.findById(clienteId);
            if (cliente == null) {
                return "Cliente no encontrado.\n";
            }

            sb.append("Mascotas del cliente: ").append(cliente.getNombres()).append("\n\n");
            List<Mascota> mascotas = mascotaDAO.findByOwner(clienteId);

            if (mascotas.isEmpty()) {
                sb.append("El cliente no tiene mascotas registradas.\n");
            } else {
                for (Mascota m : mascotas) {
                    sb.append("- ").append(m.getNombre())
                      .append(" (").append(m.getTipo())
                      .append(", ").append(m.getRaza()).append(")\n");
                }
            }

        } catch (Exception e) {
            sb.append("Error al generar el reporte: ").append(e.getMessage()).append("\n");
        }
        return sb.toString();
    }

    public String obtenerHistorialPorMascota(int mascotaId) {
        StringBuilder sb = new StringBuilder();
        try {
            Mascota mascota = mascotaDAO.findById(mascotaId);
            if (mascota == null) {
                return "Mascota no encontrada.\n";
            }

            sb.append("Mascota: ").append(mascota.getNombre())
              .append(" (").append(mascota.getTipo()).append(")\n");

            if (mascota.getOwnerId() != null) {
                Cliente cliente = clienteDAO.findById(mascota.getOwnerId());
                if (cliente != null) {
                    sb.append("Dueño: ").append(cliente.getNombres())
                      .append(" - Tel: ").append(cliente.getTelefono()).append("\n");
                }
            } else {
                sb.append("Mascota sin adoptar.\n");
            }

            sb.append("\nHistorial de consultas:\n");
            List<Consulta> consultas = consultaDAO.findByPet(mascotaId);

            if (consultas.isEmpty()) {
                sb.append("Sin consultas registradas.\n");
            } else {
                for (Consulta c : consultas) {
                    sb.append("- Fecha: ").append(c.getFecha())
                      .append(" | Síntomas: ").append(c.getSintomas())
                      .append(" | Tratamiento: ").append(c.getTratamiento())
                      .append("\n");
                }
            }

        } catch (Exception e) {
            sb.append("Error al generar el reporte: ").append(e.getMessage()).append("\n");
        }
        return sb.toString();
    }
}
