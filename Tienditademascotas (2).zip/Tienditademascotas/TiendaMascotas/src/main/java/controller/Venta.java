package controller;

public class Venta {
    private int id; private String fecha; private double valorVenta; private int clienteId; private int vendedorId; private int mascotaId;
    public Venta() {} public int getId() { return id; } public void setId(int id) { this.id = id; }
    public String getFecha() { return fecha; } public void setFecha(String fecha) { this.fecha = fecha; }
    public double getValorVenta() { return valorVenta; } public void setValorVenta(double valorVenta) { this.valorVenta = valorVenta; }
    public int getClienteId() { return clienteId; } public void setClienteId(int clienteId) { this.clienteId = clienteId; }
    public int getVendedorId() { return vendedorId; } public void setVendedorId(int vendedorId) { this.vendedorId = vendedorId; }
    public int getMascotaId() { return mascotaId; } public void setMascotaId(int mascotaId) { this.mascotaId = mascotaId; }
}
