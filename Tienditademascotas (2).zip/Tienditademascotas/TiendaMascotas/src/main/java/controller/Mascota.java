package controller;

public class Mascota {
    private int id;
    private String nombre;
    private String raza;
    private int edad;
    private String tipo;
    private int clienteId;
    private double peso;
    private String fechaIngreso;
    private String lugarOrigen;
    private String genero;
    private double precio;

    public Mascota() {}

    public Mascota(int id, String nombre, String raza, int edad, String tipo, int clienteId, double peso, String fechaIngreso, String lugarOrigen, String genero, double precio) {
        this.id=id;this.nombre=nombre;this.raza=raza;this.edad=edad;this.tipo=tipo;this.clienteId=clienteId;
        this.peso=peso;this.fechaIngreso=fechaIngreso;this.lugarOrigen=lugarOrigen;this.genero=genero;this.precio=precio;
    }

    public int getId() { return id; } public void setId(int id) { this.id = id; }
    public String getNombre() { return nombre; } public void setNombre(String nombre) { this.nombre = nombre; }
    public String getRaza() { return raza; } public void setRaza(String raza) { this.raza = raza; }
    public int getEdad() { return edad; } public void setEdad(int edad) { this.edad = edad; }
    public String getTipo() { return tipo; } public void setTipo(String tipo) { this.tipo = tipo; }
    public int getClienteId() { return clienteId; } public void setClienteId(int clienteId) { this.clienteId = clienteId; }
    public double getPeso() { return peso; } public void setPeso(double peso) { this.peso = peso; }
    public String getFechaIngreso() { return fechaIngreso; } public void setFechaIngreso(String fechaIngreso) { this.fechaIngreso = fechaIngreso; }
    public String getLugarOrigen() { return lugarOrigen; } public void setLugarOrigen(String lugarOrigen) { this.lugarOrigen = lugarOrigen; }
    public String getGenero() { return genero; } public void setGenero(String genero) { this.genero = genero; }
    public double getPrecio() { return precio; } public void setPrecio(double precio) { this.precio = precio; }

    @Override public String toString() { return id+": "+nombre+" ("+tipo+")"; }
}
