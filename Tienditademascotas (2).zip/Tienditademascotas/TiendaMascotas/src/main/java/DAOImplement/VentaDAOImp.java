/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAOImplement;

import dao.VentaDAO;
import modelo.Venta;
import util.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class VentaDAOImp implements VentaDAO {

    @Override
    public int save(Venta v) throws Exception {
        String sql = "INSERT INTO ventas(fecha, precio, client_id, vendedor, accesorios, pet_ids) VALUES(?,?,?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, v.getFecha() == null ? null : v.getFecha().toString());
            ps.setDouble(2, v.getPrecio());
            ps.setInt(3, v.getClientId());
            ps.setString(4, v.getVendedor());
            ps.setString(5, v.getAccesorios());
            ps.setString(6, v.getPetIds() == null ? null :
                    v.getPetIds().stream().map(String::valueOf).collect(Collectors.joining(",")));

            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) return rs.getInt(1);
            return -1;
        }
    }

    @Override
    public boolean update(Venta v) throws Exception {
        String sql = "UPDATE ventas SET fecha=?, precio=?, client_id=?, vendedor=?, accesorios=?, pet_ids=? WHERE id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, v.getFecha() == null ? null : v.getFecha().toString());
            ps.setDouble(2, v.getPrecio());
            ps.setInt(3, v.getClientId());
            ps.setString(4, v.getVendedor());
            ps.setString(5, v.getAccesorios());
            ps.setString(6, v.getPetIds() == null ? null :
                    v.getPetIds().stream().map(String::valueOf).collect(Collectors.joining(",")));
            ps.setInt(7, v.getId());

            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public boolean delete(int id) throws Exception {
        String sql = "DELETE FROM ventas WHERE id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public Venta findById(int id) throws Exception {
        String sql = "SELECT * FROM ventas WHERE id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);
            return null;
        }
    }

    @Override
    public List<Venta> findAll() throws Exception {
        String sql = "SELECT * FROM ventas";
        List<Venta> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    @Override
    public List<Venta> findByClient(int clientId) throws Exception {
        String sql = "SELECT * FROM ventas WHERE client_id=?";
        List<Venta> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, clientId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    private Venta mapRow(ResultSet rs) throws Exception {
        Venta v = new Venta();
        v.setId(rs.getInt("id"));
        String fechaStr = rs.getString("fecha");
        if (fechaStr != null) v.setFecha(LocalDate.parse(fechaStr));
        v.setPrecio(rs.getDouble("precio"));
        v.setClientId(rs.getInt("client_id"));
        v.setVendedor(rs.getString("vendedor"));
        v.setAccesorios(rs.getString("accesorios"));

        String petsStr = rs.getString("pet_ids");
        if (petsStr != null && !petsStr.isEmpty()) {
            List<Integer> petIds = Arrays.stream(petsStr.split(","))
                    .map(String::trim)
                    .map(Integer::parseInt)
                    .collect(Collectors.toList());
            v.setPetIds(petIds);
        } else {
            v.setPetIds(new ArrayList<>());
        }

        return v;
    }
}
