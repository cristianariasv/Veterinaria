/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import DAOImplement.ClienteDAOImp;
import DAOImplement.ConsultaDAOImp;
import DAOImplement.MascotaDAOImp;
import DAOImplement.VentaDAOImp;
import modelo.Cliente;
import modelo.Consulta;
import modelo.Mascota;
import modelo.Venta;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class MainFrame extends JFrame {

    private JPanel btnPanel;
    private JPanel contentPanel;
    private CardLayout cardLayout;

    private final MascotaDAOImp mascotaDAO = new MascotaDAOImp();
    private final ClienteDAOImp clienteDAO = new ClienteDAOImp();
    private final ConsultaDAOImp consultaDAO = new ConsultaDAOImp();
    private final VentaDAOImp ventaDAO = new VentaDAOImp();

    // Components for Mascotas
    private JTable tblMascotas;
    private DefaultTableModel modelMascotas;
    private JTextField mNombre, mRaza, mEdad, mVacunas, mTipo, mPeso, mEstado, mFechaIngreso, mLugarOrigen, mGenero, mOwnerId;
    private JButton btnMascotaSave, btnMascotaUpdate, btnMascotaDelete, btnMascotaRefresh;

    // Components for Clientes
    private JTable tblClientes;
    private DefaultTableModel modelClientes;
    private JTextField cNombres, cDireccion, cTelefono;
    private JButton btnClienteSave, btnClienteUpdate, btnClienteDelete, btnClienteRefresh;

    // Components for Consultas
    private JTable tblConsultas;
    private DefaultTableModel modelConsultas;
    private JTextField qPetId, qFecha, qSintomas, qTratamiento;
    private JButton btnConsultaSave, btnConsultaRefresh, btnConsultaDelete;

    // Components for Ventas
    private JTable tblVentas;
    private DefaultTableModel modelVentas;
    private JTextField vFecha, vPrecio, vClientId, vVendedor, vAccesorios, vPetIds;
    private JButton btnVentaSave, btnVentaRefresh, btnVentaDelete;

    // Components for Reportes
    private JTextArea txtReporte;
    private JTextField rClienteId, rMascotaId;
    private JButton btnReporteCliente, btnReporteMascota;

    public MainFrame() {
        super("Tienda de Mascotas - App");
        initUI();
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    private void initUI() {
        getContentPane().setLayout(new BorderLayout());

        btnPanel = new JPanel();
        btnPanel.setLayout(new GridLayout(5, 1, 5, 5));
        btnPanel.setPreferredSize(new Dimension(200, getHeight()));

        JButton bMascotas = new JButton("Mascotas");
        JButton bClientes = new JButton("Clientes");
        JButton bConsultas = new JButton("Consultas");
        JButton bVentas = new JButton("Ventas");
        JButton bReportes = new JButton("Reportes");

        btnPanel.add(bMascotas);
        btnPanel.add(bClientes);
        btnPanel.add(bConsultas);
        btnPanel.add(bVentas);
        btnPanel.add(bReportes);

        getContentPane().add(btnPanel, BorderLayout.WEST);

        // Content panel with CardLayout
        contentPanel = new JPanel();
        cardLayout = new CardLayout();
        contentPanel.setLayout(cardLayout);

        contentPanel.add(buildMascotasPanel(), "MASCOTAS");
        contentPanel.add(buildClientesPanel(), "CLIENTES");
        contentPanel.add(buildConsultasPanel(), "CONSULTAS");
        contentPanel.add(buildVentasPanel(), "VENTAS");
        contentPanel.add(buildReportesPanel(), "REPORTES");

        getContentPane().add(contentPanel, BorderLayout.CENTER);

        // button actions
        bMascotas.addActionListener(e -> { cardLayout.show(contentPanel, "MASCOTAS"); refreshMascotasTable(); });
        bClientes.addActionListener(e -> { cardLayout.show(contentPanel, "CLIENTES"); refreshClientesTable(); });
        bConsultas.addActionListener(e -> { cardLayout.show(contentPanel, "CONSULTAS"); refreshConsultasTable(); });
        bVentas.addActionListener(e -> { cardLayout.show(contentPanel, "VENTAS"); refreshVentasTable(); });
        bReportes.addActionListener(e -> { cardLayout.show(contentPanel, "REPORTES"); });

        // show default
        cardLayout.show(contentPanel, "MASCOTAS");
    }

    private JPanel buildMascotasPanel() {
        JPanel panel = new JPanel(new BorderLayout(8,8));

        modelMascotas = new DefaultTableModel(new Object[]{"ID","Nombre","Raza","Edad","Tipo","Estado","OwnerId"}, 0);
        tblMascotas = new JTable(modelMascotas);
        JScrollPane sp = new JScrollPane(tblMascotas);
        panel.add(sp, BorderLayout.CENTER);

        JPanel form = new JPanel(new GridLayout(6,4,6,6));
        mNombre = new JTextField();
        mRaza = new JTextField();
        mEdad = new JTextField();
        mVacunas = new JTextField();
        mTipo = new JTextField();
        mPeso = new JTextField();
        mEstado = new JTextField();
        mFechaIngreso = new JTextField(); // format YYYY-MM-DD
        mLugarOrigen = new JTextField();
        mGenero = new JTextField();
        mOwnerId = new JTextField();

        form.add(new JLabel("Nombre")); form.add(mNombre);
        form.add(new JLabel("Raza")); form.add(mRaza);
        form.add(new JLabel("Edad")); form.add(mEdad);
        form.add(new JLabel("Vacunas")); form.add(mVacunas);
        form.add(new JLabel("Tipo")); form.add(mTipo);
        form.add(new JLabel("Peso")); form.add(mPeso);
        form.add(new JLabel("Estado")); form.add(mEstado);
        form.add(new JLabel("FechaIngreso (YYYY-MM-DD)")); form.add(mFechaIngreso);
        form.add(new JLabel("LugarOrigen")); form.add(mLugarOrigen);
        form.add(new JLabel("Genero")); form.add(mGenero);
        form.add(new JLabel("OwnerId (nullable)")); form.add(mOwnerId);

        JPanel buttons = new JPanel();
        btnMascotaSave = new JButton("Guardar");
        btnMascotaUpdate = new JButton("Actualizar");
        btnMascotaDelete = new JButton("Eliminar");
        btnMascotaRefresh = new JButton("Refrescar");

        buttons.add(btnMascotaSave); buttons.add(btnMascotaUpdate); buttons.add(btnMascotaDelete); buttons.add(btnMascotaRefresh);

        panel.add(form, BorderLayout.NORTH);
        panel.add(buttons, BorderLayout.SOUTH);

        btnMascotaSave.addActionListener(e -> saveMascota());
        btnMascotaUpdate.addActionListener(e -> updateMascota());
        btnMascotaDelete.addActionListener(e -> deleteMascota());
        btnMascotaRefresh.addActionListener(e -> refreshMascotasTable());

        tblMascotas.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int r = tblMascotas.getSelectedRow();
                if (r >= 0) {
                    mNombre.setText(String.valueOf(modelMascotas.getValueAt(r,1)));
                    mRaza.setText(String.valueOf(modelMascotas.getValueAt(r,2)));
                    mEdad.setText(String.valueOf(modelMascotas.getValueAt(r,3)));
                    mTipo.setText(String.valueOf(modelMascotas.getValueAt(r,4)));
                    mEstado.setText(String.valueOf(modelMascotas.getValueAt(r,5)));
                    mOwnerId.setText(String.valueOf(modelMascotas.getValueAt(r,6)));
                }
            }
        });

        return panel;
    }

    private JPanel buildClientesPanel() {
        JPanel panel = new JPanel(new BorderLayout(8,8));

        modelClientes = new DefaultTableModel(new Object[]{"ID","Nombres","Direccion","Telefono"}, 0);
        tblClientes = new JTable(modelClientes);
        JScrollPane sp = new JScrollPane(tblClientes);
        panel.add(sp, BorderLayout.CENTER);

        JPanel form = new JPanel(new GridLayout(2,4,6,6));
        cNombres = new JTextField();
        cDireccion = new JTextField();
        cTelefono = new JTextField();

        form.add(new JLabel("Nombres")); form.add(cNombres);
        form.add(new JLabel("Direccion")); form.add(cDireccion);
        form.add(new JLabel("Telefono")); form.add(cTelefono);

        JPanel buttons = new JPanel();
        btnClienteSave = new JButton("Guardar");
        btnClienteUpdate = new JButton("Actualizar");
        btnClienteDelete = new JButton("Eliminar");
        btnClienteRefresh = new JButton("Refrescar");

        buttons.add(btnClienteSave); buttons.add(btnClienteUpdate); buttons.add(btnClienteDelete); buttons.add(btnClienteRefresh);

        panel.add(form, BorderLayout.NORTH);
        panel.add(buttons, BorderLayout.SOUTH);

        btnClienteSave.addActionListener(e -> saveCliente());
        btnClienteUpdate.addActionListener(e -> updateCliente());
        btnClienteDelete.addActionListener(e -> deleteCliente());
        btnClienteRefresh.addActionListener(e -> refreshClientesTable());

        tblClientes.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int r = tblClientes.getSelectedRow();
                if (r >= 0) {
                    cNombres.setText(String.valueOf(modelClientes.getValueAt(r,1)));
                    cDireccion.setText(String.valueOf(modelClientes.getValueAt(r,2)));
                    cTelefono.setText(String.valueOf(modelClientes.getValueAt(r,3)));
                }
            }
        });

        return panel;
    }

    private JPanel buildConsultasPanel() {
        JPanel panel = new JPanel(new BorderLayout(8,8));

        modelConsultas = new DefaultTableModel(new Object[]{"ID","PetId","Fecha","Sintomas","Tratamiento"}, 0);
        tblConsultas = new JTable(modelConsultas);
        panel.add(new JScrollPane(tblConsultas), BorderLayout.CENTER);

        JPanel form = new JPanel(new GridLayout(2,4,6,6));
        qPetId = new JTextField();
        qFecha = new JTextField(); // YYYY-MM-DD
        qSintomas = new JTextField();
        qTratamiento = new JTextField();

        form.add(new JLabel("PetId")); form.add(qPetId);
        form.add(new JLabel("Fecha (YYYY-MM-DD)")); form.add(qFecha);
        form.add(new JLabel("Sintomas")); form.add(qSintomas);
        form.add(new JLabel("Tratamiento")); form.add(qTratamiento);

        JPanel buttons = new JPanel();
        btnConsultaSave = new JButton("Guardar");
        btnConsultaRefresh = new JButton("Refrescar");
        btnConsultaDelete = new JButton("Eliminar");

        buttons.add(btnConsultaSave); buttons.add(btnConsultaRefresh); buttons.add(btnConsultaDelete);

        panel.add(form, BorderLayout.NORTH);
        panel.add(buttons, BorderLayout.SOUTH);

        btnConsultaSave.addActionListener(e -> saveConsulta());
        btnConsultaRefresh.addActionListener(e -> refreshConsultasTable());
        btnConsultaDelete.addActionListener(e -> deleteConsulta());

        tblConsultas.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int r = tblConsultas.getSelectedRow();
                if (r >= 0) {
                    qPetId.setText(String.valueOf(modelConsultas.getValueAt(r,1)));
                    qFecha.setText(String.valueOf(modelConsultas.getValueAt(r,2)));
                    qSintomas.setText(String.valueOf(modelConsultas.getValueAt(r,3)));
                    qTratamiento.setText(String.valueOf(modelConsultas.getValueAt(r,4)));
                }
            }
        });

        return panel;
    }

    private JPanel buildVentasPanel() {
        JPanel panel = new JPanel(new BorderLayout(8,8));

        modelVentas = new DefaultTableModel(new Object[]{"ID","Fecha","Precio","ClientId","Vendedor","Accesorios","PetIds"}, 0);
        tblVentas = new JTable(modelVentas);
        panel.add(new JScrollPane(tblVentas), BorderLayout.CENTER);

        JPanel form = new JPanel(new GridLayout(3,4,6,6));
        vFecha = new JTextField(); // YYYY-MM-DD
        vPrecio = new JTextField();
        vClientId = new JTextField();
        vVendedor = new JTextField();
        vAccesorios = new JTextField();
        vPetIds = new JTextField(); // comma separated ids

        form.add(new JLabel("Fecha (YYYY-MM-DD)")); form.add(vFecha);
        form.add(new JLabel("Precio")); form.add(vPrecio);
        form.add(new JLabel("ClientId")); form.add(vClientId);
        form.add(new JLabel("Vendedor")); form.add(vVendedor);
        form.add(new JLabel("Accesorios")); form.add(vAccesorios);
        form.add(new JLabel("PetIds (1,2,3)")); form.add(vPetIds);

        JPanel buttons = new JPanel();
        btnVentaSave = new JButton("Guardar");
        btnVentaRefresh = new JButton("Refrescar");
        btnVentaDelete = new JButton("Eliminar");

        buttons.add(btnVentaSave); buttons.add(btnVentaRefresh); buttons.add(btnVentaDelete);

        panel.add(form, BorderLayout.NORTH);
        panel.add(buttons, BorderLayout.SOUTH);

        btnVentaSave.addActionListener(e -> saveVenta());
        btnVentaRefresh.addActionListener(e -> refreshVentasTable());
        btnVentaDelete.addActionListener(e -> deleteVenta());

        tblVentas.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int r = tblVentas.getSelectedRow();
                if (r >= 0) {
                    vFecha.setText(String.valueOf(modelVentas.getValueAt(r,1)));
                    vPrecio.setText(String.valueOf(modelVentas.getValueAt(r,2)));
                    vClientId.setText(String.valueOf(modelVentas.getValueAt(r,3)));
                    vVendedor.setText(String.valueOf(modelVentas.getValueAt(r,4)));
                    vAccesorios.setText(String.valueOf(modelVentas.getValueAt(r,5)));
                    vPetIds.setText(String.valueOf(modelVentas.getValueAt(r,6)));
                }
            }
        });

        return panel;
    }

    private JPanel buildReportesPanel() {
        JPanel panel = new JPanel(new BorderLayout(8,8));

        JPanel top = new JPanel(new GridLayout(2,4,6,6));
        rClienteId = new JTextField();
        rMascotaId = new JTextField();
        btnReporteCliente = new JButton("Reporte por Cliente");
        btnReporteMascota = new JButton("Reporte por Mascota");

        top.add(new JLabel("ID Cliente")); top.add(rClienteId); top.add(btnReporteCliente);
        top.add(new JLabel("ID Mascota")); top.add(rMascotaId); top.add(btnReporteMascota);

        txtReporte = new JTextArea();
        txtReporte.setEditable(false);
        JScrollPane sp = new JScrollPane(txtReporte);

        panel.add(top, BorderLayout.NORTH);
        panel.add(sp, BorderLayout.CENTER);

        btnReporteCliente.addActionListener(e -> generarReporteCliente());
        btnReporteMascota.addActionListener(e -> generarReporteMascota());

        return panel;
    }

    // ----------------- MASCOTAS CRUD -----------------
    private void saveMascota() {
        try {
            Mascota m = new Mascota();
            m.setNombre(mNombre.getText());
            m.setRaza(mRaza.getText());
            m.setEdad(parseIntOrZero(mEdad.getText()));
            m.setVacunas(mVacunas.getText());
            m.setTipo(mTipo.getText());
            m.setPeso(parseDoubleOrZero(mPeso.getText()));
            m.setEstado(mEstado.getText());
            if (!mFechaIngreso.getText().trim().isEmpty()) m.setFechaIngreso(LocalDate.parse(mFechaIngreso.getText().trim()));
            m.setLugarOrigen(mLugarOrigen.getText());
            m.setGenero(mGenero.getText());
            String owner = mOwnerId.getText().trim();
            if (!owner.isEmpty()) m.setOwnerId(Integer.valueOf(owner));
            else m.setOwnerId(null);

            int id = mascotaDAO.save(m);
            JOptionPane.showMessageDialog(this, "Mascota guardada con ID: " + id);
            clearMascotaForm();
            refreshMascotasTable();
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void updateMascota() {
        try {
            int r = tblMascotas.getSelectedRow();
            if (r < 0) { JOptionPane.showMessageDialog(this, "Seleccione una mascota de la tabla"); return; }
            int id = (int) modelMascotas.getValueAt(r,0);
            Mascota m = new Mascota();
            m.setId(id);
            m.setNombre(mNombre.getText());
            m.setRaza(mRaza.getText());
            m.setEdad(parseIntOrZero(mEdad.getText()));
            m.setVacunas(mVacunas.getText());
            m.setTipo(mTipo.getText());
            m.setPeso(parseDoubleOrZero(mPeso.getText()));
            m.setEstado(mEstado.getText());
            if (!mFechaIngreso.getText().trim().isEmpty()) m.setFechaIngreso(LocalDate.parse(mFechaIngreso.getText().trim()));
            m.setLugarOrigen(mLugarOrigen.getText());
            m.setGenero(mGenero.getText());
            String owner = mOwnerId.getText().trim();
            if (!owner.isEmpty()) m.setOwnerId(Integer.valueOf(owner));
            else m.setOwnerId(null);

            boolean ok = mascotaDAO.update(m);
            JOptionPane.showMessageDialog(this, ok ? "Mascota actualizada" : "No se pudo actualizar");
            clearMascotaForm();
            refreshMascotasTable();
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void deleteMascota() {
        try {
            int r = tblMascotas.getSelectedRow();
            if (r < 0) { JOptionPane.showMessageDialog(this, "Seleccione una mascota de la tabla"); return; }
            int id = (int) modelMascotas.getValueAt(r,0);
            boolean ok = mascotaDAO.delete(id);
            JOptionPane.showMessageDialog(this, ok ? "Mascota eliminada" : "No se pudo eliminar");
            refreshMascotasTable();
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void refreshMascotasTable() {
        try {
            modelMascotas.setRowCount(0);
            List<Mascota> list = mascotaDAO.findAll();
            for (Mascota m : list) {
                modelMascotas.addRow(new Object[]{
                        m.getId(), m.getNombre(), m.getRaza(), m.getEdad(), m.getTipo(), m.getEstado(), m.getOwnerId()
                });
            }
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void clearMascotaForm() {
        mNombre.setText(""); mRaza.setText(""); mEdad.setText(""); mVacunas.setText(""); mTipo.setText("");
        mPeso.setText(""); mEstado.setText(""); mFechaIngreso.setText(""); mLugarOrigen.setText(""); mGenero.setText(""); mOwnerId.setText("");
    }

    // ----------------- CLIENTES CRUD -----------------
    private void saveCliente() {
        try {
            Cliente c = new Cliente();
            c.setNombres(cNombres.getText());
            c.setDireccion(cDireccion.getText());
            c.setTelefono(cTelefono.getText());
            int id = clienteDAO.save(c);
            JOptionPane.showMessageDialog(this, "Cliente guardado con ID: " + id);
            clearClienteForm();
            refreshClientesTable();
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void updateCliente() {
        try {
            int r = tblClientes.getSelectedRow();
            if (r < 0) { JOptionPane.showMessageDialog(this, "Seleccione un cliente"); return; }
            int id = (int) modelClientes.getValueAt(r,0);
            Cliente c = new Cliente();
            c.setId(id);
            c.setNombres(cNombres.getText());
            c.setDireccion(cDireccion.getText());
            c.setTelefono(cTelefono.getText());
            boolean ok = clienteDAO.update(c);
            JOptionPane.showMessageDialog(this, ok ? "Cliente actualizado" : "No se pudo actualizar");
            clearClienteForm();
            refreshClientesTable();
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void deleteCliente() {
        try {
            int r = tblClientes.getSelectedRow();
            if (r < 0) { JOptionPane.showMessageDialog(this, "Seleccione un cliente"); return; }
            int id = (int) modelClientes.getValueAt(r,0);
            boolean ok = clienteDAO.delete(id);
            JOptionPane.showMessageDialog(this, ok ? "Cliente eliminado" : "No se pudo eliminar");
            refreshClientesTable();
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void refreshClientesTable() {
        try {
            modelClientes.setRowCount(0);
            List<Cliente> list = clienteDAO.findAll();
            for (Cliente c : list) {
                modelClientes.addRow(new Object[]{c.getId(), c.getNombres(), c.getDireccion(), c.getTelefono()});
            }
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void clearClienteForm() { cNombres.setText(""); cDireccion.setText(""); cTelefono.setText(""); }

    // ----------------- CONSULTAS CRUD -----------------
    private void saveConsulta() {
        try {
            Consulta c = new Consulta();
            c.setPetId(parseIntOrZero(qPetId.getText()));
            if (!qFecha.getText().trim().isEmpty()) c.setFecha(LocalDate.parse(qFecha.getText().trim()));
            c.setSintomas(qSintomas.getText());
            c.setTratamiento(qTratamiento.getText());
            int id = consultaDAO.save(c);
            JOptionPane.showMessageDialog(this, "Consulta guardada con ID: " + id);
            clearConsultaForm();
            refreshConsultasTable();
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void deleteConsulta() {
        try {
            int r = tblConsultas.getSelectedRow();
            if (r < 0) { JOptionPane.showMessageDialog(this, "Seleccione una consulta"); return; }
            int id = (int) modelConsultas.getValueAt(r,0);
            boolean ok = consultaDAO.delete(id);
            JOptionPane.showMessageDialog(this, ok ? "Consulta eliminada" : "No se pudo eliminar");
            refreshConsultasTable();
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void refreshConsultasTable() {
        try {
            modelConsultas.setRowCount(0);
            List<Consulta> list = consultaDAO.findAll();
            for (Consulta c : list) {
                modelConsultas.addRow(new Object[]{c.getId(), c.getPetId(), c.getFecha(), c.getSintomas(), c.getTratamiento()});
            }
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void clearConsultaForm() {
        qPetId.setText(""); qFecha.setText(""); qSintomas.setText(""); qTratamiento.setText("");
    }

    // ----------------- VENTAS CRUD -----------------
    private void saveVenta() {
        try {
            Venta v = new Venta();
            if (!vFecha.getText().trim().isEmpty()) v.setFecha(LocalDate.parse(vFecha.getText().trim()));
            v.setPrecio(parseDoubleOrZero(vPrecio.getText()));
            v.setClientId(parseIntOrZero(vClientId.getText()));
            v.setVendedor(vVendedor.getText());
            v.setAccesorios(vAccesorios.getText());
            String petIdsText = vPetIds.getText().trim();
            if (!petIdsText.isEmpty()) {
                List<Integer> ids = Arrays.stream(petIdsText.split(","))
                        .map(String::trim).filter(s->!s.isEmpty()).map(Integer::parseInt)
                        .collect(Collectors.toList());
                v.setPetIds(ids);
            } else v.setPetIds(new ArrayList<>());

            int id = ventaDAO.save(v);

            // opcional: marcar mascotas como adoptadas y poner ownerId
            // si hay clientId válido y petIds
            if (v.getClientId() > 0 && v.getPetIds() != null) {
                for (Integer pid : v.getPetIds()) {
                    try {
                        Mascota m = mascotaDAO.findById(pid);
                        if (m != null) {
                            m.setOwnerId(v.getClientId());
                            m.setEstado("adoptado");
                            mascotaDAO.update(m);
                        }
                    } catch (Exception ex) { /* ignorar por mascota individual */ }
                }
            }

            JOptionPane.showMessageDialog(this, "Venta guardada con ID: " + id);
            clearVentaForm();
            refreshVentasTable();
            refreshMascotasTable();
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void deleteVenta() {
        try {
            int r = tblVentas.getSelectedRow();
            if (r < 0) { JOptionPane.showMessageDialog(this, "Seleccione una venta"); return; }
            int id = (int) modelVentas.getValueAt(r,0);
            boolean ok = ventaDAO.delete(id);
            JOptionPane.showMessageDialog(this, ok ? "Venta eliminada" : "No se pudo eliminar");
            refreshVentasTable();
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void refreshVentasTable() {
        try {
            modelVentas.setRowCount(0);
            List<Venta> list = ventaDAO.findAll();
            for (Venta v : list) {
                modelVentas.addRow(new Object[]{v.getId(), v.getFecha(), v.getPrecio(), v.getClientId(), v.getVendedor(), v.getAccesorios(),
                        v.getPetIds() == null ? "" : v.getPetIds().stream().map(String::valueOf).collect(Collectors.joining(","))});
            }
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void clearVentaForm() {
        vFecha.setText(""); vPrecio.setText(""); vClientId.setText(""); vVendedor.setText(""); vAccesorios.setText(""); vPetIds.setText("");
    }

    // ----------------- REPORTES -----------------
    private void generarReporteCliente() {
        try {
            int clienteId = parseIntOrZero(rClienteId.getText());
            if (clienteId <= 0) { JOptionPane.showMessageDialog(this, "Ingrese un ID de cliente válido"); return; }
            Cliente c = clienteDAO.findById(clienteId);
            if (c == null) { txtReporte.setText("Cliente no encontrado."); return; }
            StringBuilder sb = new StringBuilder();
            sb.append("Mascotas del cliente: ").append(c.getNombres()).append("\n\n");
            List<Mascota> mascotas = mascotaDAO.findByOwner(clienteId);
            if (mascotas.isEmpty()) sb.append("Sin mascotas registradas.");
            else {
                for (Mascota m : mascotas) {
                    sb.append("- ID ").append(m.getId()).append(" - ").append(m.getNombre())
                            .append(" (").append(m.getTipo()).append(", ").append(m.getRaza()).append(")\n");
                }
            }
            txtReporte.setText(sb.toString());
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void generarReporteMascota() {
        try {
            int mascotaId = parseIntOrZero(rMascotaId.getText());
            if (mascotaId <= 0) { JOptionPane.showMessageDialog(this, "Ingrese un ID de mascota válido"); return; }
            Mascota m = mascotaDAO.findById(mascotaId);
            if (m == null) { txtReporte.setText("Mascota no encontrada."); return; }
            StringBuilder sb = new StringBuilder();
            sb.append("Mascota: ").append(m.getNombre()).append(" (").append(m.getTipo()).append(")\n");
            if (m.getOwnerId() != null) {
                Cliente c = clienteDAO.findById(m.getOwnerId());
                if (c != null) sb.append("Dueño: ").append(c.getNombres()).append(" - Tel: ").append(c.getTelefono()).append("\n");
            } else sb.append("Mascota sin adoptar.\n");

            sb.append("\nHistorial de consultas:\n");
            List<Consulta> consultas = consultaDAO.findByPet(mascotaId);
            if (consultas.isEmpty()) sb.append("Sin consultas registradas.");
            else {
                for (Consulta c : consultas) {
                    sb.append("- ").append(c.getFecha()).append(" | ").append(c.getSintomas())
                            .append(" | ").append(c.getTratamiento()).append("\n");
                }
            }
            txtReporte.setText(sb.toString());
        } catch (Exception ex) {
            showError(ex);
        }
    }

    // ----------------- Utilities -----------------
    private int parseIntOrZero(String s) {
        try { return Integer.parseInt(s.trim()); } catch (NumberFormatException ex) { return 0; }
    }

    private double parseDoubleOrZero(String s) {
        try { return Double.parseDouble(s.trim()); } catch (NumberFormatException ex) { return 0.0; }
    }

    private void showError(Exception ex) {
        JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
    }

// ----------------- Main -----------------
public static void main(String[] args) {
    // Crear las tablas si no existen
    util.SQLScripts.createTablesIfNotExists();

    SwingUtilities.invokeLater(() -> {
        MainFrame mf = new MainFrame();
        mf.setVisible(true);
        // cargar datos iniciales
        mf.refreshClientesTable();
        mf.refreshMascotasTable();
        mf.refreshConsultasTable();
        mf.refreshVentasTable();
    });
}
}