/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

import java.sql.Connection;
import java.sql.Statement;

public class SQLScripts {

    public static void createTablesIfNotExists() {
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement()) {

            // Tabla de clientes
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS clients (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nombre TEXT NOT NULL,
                    direccion TEXT,
                    telefono TEXT
                );
            """);

            // Tabla de mascotas
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS mascotas (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nombre TEXT NOT NULL,
                    especie TEXT,
                    raza TEXT,
                    edad INTEGER,
                    id_cliente INTEGER,
                    FOREIGN KEY(id_cliente) REFERENCES clients(id)
                );
            """);

            // Tabla de consultas
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS consultas (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    id_mascota INTEGER,
                    fecha TEXT,
                    motivo TEXT,
                    tratamiento TEXT,
                    FOREIGN KEY(id_mascota) REFERENCES mascotas(id)
                );
            """);

            // Tabla de ventas
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS ventas (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    fecha TEXT,
                    total REAL
                );
            """);

        } catch (Exception e) {
            System.err.println("Error al crear tablas: " + e.getMessage());
        }
    }
}