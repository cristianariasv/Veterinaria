/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao;

import java.util.List;
import modelo.Mascota;

public interface MascotaDAO extends GenericoDAO<Mascota> {
    List<Mascota> findByOwner(int ownerId) throws Exception;
    List<Mascota> findAvailable() throws Exception;
}
