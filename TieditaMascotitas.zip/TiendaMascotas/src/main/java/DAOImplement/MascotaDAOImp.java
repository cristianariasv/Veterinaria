/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAOImplement;

import dao.MascotaDAO;
import modelo.Mascota;
import util.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class MascotaDAOImp implements MascotaDAO {

    @Override
    public int save(Mascota p) throws Exception {
        String sql = "INSERT INTO pets(nombre,raza,edad,vacunas,tipo,peso,estado,fecha_ingreso,lugar_origen,genero,owner_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getRaza());
            ps.setInt(3, p.getEdad());
            ps.setString(4, p.getVacunas());
            ps.setString(5, p.getTipo());
            ps.setDouble(6, p.getPeso());
            ps.setString(7, p.getEstado());
            ps.setString(8, p.getFechaIngreso() == null ? null : p.getFechaIngreso().toString());
            ps.setString(9, p.getLugarOrigen());
            ps.setString(10, p.getGenero());
            if (p.getOwnerId() == null) ps.setNull(11, Types.INTEGER);
            else ps.setInt(11, p.getOwnerId());
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) return rs.getInt(1);
            return -1;
        }
    }

    @Override
    public boolean update(Mascota p) throws Exception {
        String sql = "UPDATE pets SET nombre=?,raza=?,edad=?,vacunas=?,tipo=?,peso=?,estado=?,fecha_ingreso=?,lugar_origen=?,genero=?,owner_id=? WHERE id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getRaza());
            ps.setInt(3, p.getEdad());
            ps.setString(4, p.getVacunas());
            ps.setString(5, p.getTipo());
            ps.setDouble(6, p.getPeso());
            ps.setString(7, p.getEstado());
            ps.setString(8, p.getFechaIngreso() == null ? null : p.getFechaIngreso().toString());
            ps.setString(9, p.getLugarOrigen());
            ps.setString(10, p.getGenero());
            if (p.getOwnerId() == null) ps.setNull(11, Types.INTEGER);
            else ps.setInt(11, p.getOwnerId());
            ps.setInt(12, p.getId());
            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public boolean delete(int id) throws Exception {
        String sql = "DELETE FROM pets WHERE id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1,id);
            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public Mascota findById(int id) throws Exception {
        String sql = "SELECT * FROM pets WHERE id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1,id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Mascota p = mapRow(rs);
                return p;
            }
            return null;
        }
    }

    @Override
    public List<Mascota> findAll() throws Exception {
        String sql = "SELECT * FROM pets";
        List<Mascota> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    @Override
    public List<Mascota> findByOwner(int ownerId) throws Exception {
        String sql = "SELECT * FROM pets WHERE owner_id=?";
        List<Mascota> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, ownerId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    @Override
    public List<Mascota> findAvailable() throws Exception {
        String sql = "SELECT * FROM pets WHERE estado='sin adoptar' OR estado IS NULL";
        List<Mascota> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    private Mascota mapRow(ResultSet rs) throws Exception {
        Mascota p = new Mascota();
        p.setId(rs.getInt("id"));
        p.setNombre(rs.getString("nombre"));
        p.setRaza(rs.getString("raza"));
        p.setEdad(rs.getInt("edad"));
        p.setVacunas(rs.getString("vacunas"));
        p.setTipo(rs.getString("tipo"));
        p.setPeso(rs.getDouble("peso"));
        p.setEstado(rs.getString("estado"));
        String f = rs.getString("fecha_ingreso");
        if (f != null) p.setFechaIngreso(LocalDate.parse(f));
        p.setLugarOrigen(rs.getString("lugar_origen"));
        p.setGenero(rs.getString("genero"));
        int owner = rs.getInt("owner_id");
        if (!rs.wasNull()) p.setOwnerId(owner);
        else p.setOwnerId(null);
        return p;
    }
}
