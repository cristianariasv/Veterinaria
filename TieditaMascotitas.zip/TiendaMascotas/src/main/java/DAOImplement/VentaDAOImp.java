/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAOImplement;

import dao.VentaDAO;
import modelo.Venta;
import util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class VentaDAOImp implements VentaDAO {

    @Override
    public int save(Venta v) throws Exception {
        String sql = "INSERT INTO Venta (fecha, precio, clientId, vendedor, accesorios, petIds) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            if (v.getFecha() != null) ps.setDate(1, Date.valueOf(v.getFecha()));
            else ps.setNull(1, Types.DATE);

            ps.setDouble(2, v.getPrecio());
            ps.setInt(3, v.getClientId());
            ps.setString(4, v.getVendedor());
            ps.setString(5, v.getAccesorios());

            if (v.getPetIds() != null && !v.getPetIds().isEmpty()) {
                String petIds = v.getPetIds().toString().replace("[", "").replace("]", "");
                ps.setString(6, petIds);
            } else ps.setNull(6, Types.VARCHAR);

            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return -1;
    }

    @Override
    public boolean delete(int id) throws Exception {
        String sql = "DELETE FROM Venta WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }

    @Override
    public List<Venta> findAll() throws Exception {
        List<Venta> list = new ArrayList<>();
        String sql = "SELECT id, fecha, precio, clientId, vendedor, accesorios, petIds FROM Venta";
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Venta v = new Venta();
                v.setId(rs.getInt("id"));

                Date fecha = rs.getDate("fecha");
                if (fecha != null) v.setFecha(fecha.toLocalDate());

                v.setPrecio(rs.getDouble("precio"));
                v.setClientId(rs.getInt("clientId"));
                v.setVendedor(rs.getString("vendedor"));
                v.setAccesorios(rs.getString("accesorios"));

                String petIds = rs.getString("petIds");
                if (petIds != null && !petIds.trim().isEmpty()) {
                    List<Integer> ids = Arrays.stream(petIds.split(","))
                            .map(String::trim)
                            .filter(s -> !s.isEmpty())
                            .map(Integer::parseInt)
                            .toList();
                    v.setPetIds(ids);
                } else {
                    v.setPetIds(new ArrayList<>());
                }

                list.add(v);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return list;
    }

    @Override
    public List<Venta> findByClient(int clientId) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean update(Venta t) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Venta findById(int id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
