/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAOImplement;

import dao.ConsultaDAO;
import modelo.Consulta;
import util.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ConsultaDAOImp implements ConsultaDAO {

    @Override
    public int save(Consulta c) throws Exception {
        String sql = "INSERT INTO consultas(pet_id, fecha, sintomas, tratamiento) VALUES (?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, c.getPetId());
            ps.setString(2, c.getFecha() == null ? null : c.getFecha().toString());
            ps.setString(3, c.getSintomas());
            ps.setString(4, c.getTratamiento());
            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) return rs.getInt(1);
            return -1;
        }
    }

    @Override
    public boolean update(Consulta c) throws Exception {
        String sql = "UPDATE consultas SET pet_id = ?, fecha = ?, sintomas = ?, tratamiento = ? WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, c.getPetId());
            ps.setString(2, c.getFecha() == null ? null : c.getFecha().toString());
            ps.setString(3, c.getSintomas());
            ps.setString(4, c.getTratamiento());
            ps.setInt(5, c.getId());

            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public boolean delete(int id) throws Exception {
        String sql = "DELETE FROM consultas WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public Consulta findById(int id) throws Exception {
        String sql = "SELECT * FROM consultas WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return mapRow(rs);
            }
            return null;
        }
    }

    @Override
    public List<Consulta> findAll() throws Exception {
        String sql = "SELECT * FROM consultas";
        List<Consulta> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    @Override
    public List<Consulta> findByPet(int petId) throws Exception {
        String sql = "SELECT * FROM consultas WHERE pet_id = ?";
        List<Consulta> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, petId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));

        }
        return list;
    }


    private Consulta mapRow(ResultSet rs) throws Exception {
        Consulta c = new Consulta();
        c.setId(rs.getInt("id"));
        c.setPetId(rs.getInt("pet_id"));
        String fechaStr = rs.getString("fecha");
        if (fechaStr != null) c.setFecha(LocalDate.parse(fechaStr));
        c.setSintomas(rs.getString("sintomas"));
        c.setTratamiento(rs.getString("tratamiento"));
        return c;
    }
}
