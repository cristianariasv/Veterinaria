package controller;

public class Detalle {
    private int id; private int cantidad; private int ventaId; private int accesorioId;
    public Detalle() {} public int getId() { return id; } public void setId(int id) { this.id = id; }
    public int getCantidad() { return cantidad; } public void setCantidad(int cantidad) { this.cantidad = cantidad; }
    public int getVentaId() { return ventaId; } public void setVentaId(int ventaId) { this.ventaId = ventaId; }
    public int getAccesorioId() { return accesorioId; } public void setAccesorioId(int accesorioId) { this.accesorioId = accesorioId; }
}
