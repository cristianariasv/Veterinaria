package controller;

public class Dosis {
    private int id; private String fecha; private double cantidad; private int vacunaId; private int mascotaId;
    public Dosis() {}
    public int getId() { return id; } public void setId(int id) { this.id = id; }
    public String getFecha() { return fecha; } public void setFecha(String fecha) { this.fecha = fecha; }
    public double getCantidad() { return cantidad; } public void setCantidad(double cantidad) { this.cantidad = cantidad; }
    public int getVacunaId() { return vacunaId; } public void setVacunaId(int vacunaId) { this.vacunaId = vacunaId; }
    public int getMascotaId() { return mascotaId; } public void setMascotaId(int mascotaId) { this.mascotaId = mascotaId; }
}
