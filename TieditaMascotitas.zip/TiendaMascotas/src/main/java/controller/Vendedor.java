package controller;

public class Vendedor {
    private int id;
    private String identificacion;
    private String nombres;
    private String genero;

    public Vendedor() {}
    public Vendedor(int id, String identificacion, String nombres, String genero) { this.id=id; this.identificacion=identificacion; this.nombres=nombres; this.genero=genero;}

    public int getId() { return id; } public void setId(int id) { this.id = id; }
    public String getIdentificacion() { return identificacion; } public void setIdentificacion(String identificacion) { this.identificacion = identificacion; }
    public String getNombres() { return nombres; } public void setNombres(String nombres) { this.nombres = nombres; }
    public String getGenero() { return genero; } public void setGenero(String genero) { this.genero = genero; }

    @Override public String toString() { return id+": "+nombres; }
}
