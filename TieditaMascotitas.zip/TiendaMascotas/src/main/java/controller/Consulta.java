package controller;

public class Consulta {
    private int id; private String fecha; private String sintomas; private String tratamiento; private int mascotaId;
    public Consulta() {} public int getId() { return id; } public void setId(int id) { this.id = id; }
    public String getFecha() { return fecha; } public void setFecha(String fecha) { this.fecha = fecha; }
    public String getSintomas() { return sintomas; } public void setSintomas(String sintomas) { this.sintomas = sintomas; }
    public String getTratamiento() { return tratamiento; } public void setTratamiento(String tratamiento) { this.tratamiento = tratamiento; }
    public int getMascotaId() { return mascotaId; } public void setMascotaId(int mascotaId) { this.mascotaId = mascotaId; }
}
